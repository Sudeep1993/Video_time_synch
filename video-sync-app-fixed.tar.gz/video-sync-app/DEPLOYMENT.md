# 🚀 Deployment Guide

This guide will help you deploy the Video Synchronization Tool to various platforms.

## 📋 Table of Contents

- [GitHub Pages (Recommended)](#github-pages)
- [Netlify](#netlify)
- [Vercel](#vercel)
- [Local Server](#local-server)

---

## 🌐 GitHub Pages (Recommended)

GitHub Pages is the easiest way to deploy this application for free.

### Step 1: Create a GitHub Repository

1. Go to [GitHub](https://github.com) and create a new repository
2. Name it `video-sync-app` (or any name you prefer)
3. Make it public
4. Don't initialize with README (we already have one)

### Step 2: Push Your Code

```bash
# Navigate to your project directory
cd video-sync-app

# Initialize git repository
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit - Video Sync App"

# Add remote repository (replace 'yourusername' with your GitHub username)
git remote add origin https://github.com/yourusername/video-sync-app.git

# Push to GitHub
git branch -M main
git push -u origin main
```

### Step 3: Enable GitHub Pages

1. Go to your repository on GitHub
2. Click **Settings**
3. Scroll down to **Pages** in the left sidebar
4. Under **Source**, select **main** branch
5. Click **Save**

### Step 4: Access Your Site

After a few minutes, your site will be live at:
```
https://yourusername.github.io/video-sync-app/
```

---

## 🎨 Netlify

Netlify offers instant deployment with continuous integration.

### Method 1: Drag and Drop

1. Go to [Netlify](https://www.netlify.com/)
2. Sign up or log in
3. Drag and drop your project folder to the deploy zone
4. Your site will be live instantly!

### Method 2: GitHub Integration

1. Push your code to GitHub (see GitHub Pages steps above)
2. Go to [Netlify](https://www.netlify.com/)
3. Click **New site from Git**
4. Connect your GitHub account
5. Select your repository
6. Click **Deploy site**

Your site will be live at a random Netlify URL. You can customize this in settings.

---

## ⚡ Vercel

Vercel provides fast deployment with excellent performance.

### Using Vercel CLI

```bash
# Install Vercel CLI
npm install -g vercel

# Navigate to your project
cd video-sync-app

# Deploy
vercel

# Follow the prompts:
# - Login to Vercel
# - Set up project
# - Deploy
```

### Using Vercel Website

1. Push your code to GitHub
2. Go to [Vercel](https://vercel.com/)
3. Click **New Project**
4. Import your GitHub repository
5. Click **Deploy**

---

## 💻 Local Server

For testing or local use:

### Option 1: Python HTTP Server

```bash
# Python 3
python -m http.server 8000

# Python 2
python -m SimpleHTTPServer 8000

# Access at: http://localhost:8000
```

### Option 2: Node.js http-server

```bash
# Install http-server globally
npm install -g http-server

# Run server
http-server -p 8000

# Access at: http://localhost:8000
```

### Option 3: Live Server (VS Code Extension)

1. Install "Live Server" extension in VS Code
2. Right-click `index.html`
3. Select "Open with Live Server"

---

## 🔧 Custom Domain Setup

### GitHub Pages with Custom Domain

1. Purchase a domain from a registrar (GoDaddy, Namecheap, etc.)
2. In your repository settings > Pages
3. Enter your custom domain under "Custom domain"
4. In your domain registrar's DNS settings, add:
   ```
   Type: CNAME
   Name: www
   Value: yourusername.github.io
   ```
5. Wait for DNS propagation (up to 24 hours)

### Netlify with Custom Domain

1. In Netlify dashboard, go to your site
2. Click **Domain settings**
3. Click **Add custom domain**
4. Follow the DNS configuration instructions

---

## 📦 Build Optimization (Optional)

For production deployment, you can optimize the application:

### Minify JavaScript

```bash
# Install terser
npm install -g terser

# Minify app.js
terser app.js -c -m -o app.min.js
```

### Minify CSS

```bash
# Install clean-css-cli
npm install -g clean-css-cli

# Minify styles.css
cleancss -o styles.min.css styles.css
```

Then update `index.html` to use the minified versions:
```html
<link rel="stylesheet" href="styles.min.css">
<script src="app.min.js"></script>
```

---

## 🔒 Security Considerations

- The application runs entirely in the browser (client-side)
- No data is sent to external servers
- Videos are processed locally in the user's browser
- Use HTTPS (GitHub Pages, Netlify, and Vercel provide this automatically)

---

## 🐛 Troubleshooting

### Issue: Site not loading after GitHub Pages deployment

**Solution**: 
- Wait a few minutes for deployment to complete
- Check if you selected the correct branch in Pages settings
- Clear your browser cache

### Issue: OpenCV.js or Tesseract.js not loading

**Solution**:
- Ensure you have a stable internet connection
- The CDN links in `index.html` must be accessible
- Check browser console for errors

### Issue: Videos not processing

**Solution**:
- Ensure videos are in supported formats (MP4, MOV, AVI)
- Check video file size (large files may cause memory issues)
- Try with smaller video files first
- Check browser console for errors

### Issue: CORS errors in local development

**Solution**:
- Don't open `index.html` directly (use file:// protocol)
- Instead, use a local server (Python, Node.js, etc.)
- This is required for video file processing

---

## 📊 Analytics (Optional)

Add Google Analytics to track usage:

1. Create a Google Analytics account
2. Get your tracking ID
3. Add before `</head>` in `index.html`:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

---

## 🎯 Performance Tips

1. **Use CDN versions** of OpenCV.js and Tesseract.js (already configured)
2. **Lazy load** heavy libraries only when needed
3. **Compress videos** before uploading
4. **Use WebP images** if adding screenshots/assets
5. **Enable caching** on your hosting platform

---

## 📞 Need Help?

- Open an issue on GitHub
- Check the [README.md](README.md) for usage instructions
- Review browser console for error messages

---

**Happy Deploying! 🚀**
