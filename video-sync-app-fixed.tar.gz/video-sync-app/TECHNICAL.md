# 🔧 Technical Documentation

Complete technical reference for the Video Synchronization Tool.

## 📋 Table of Contents

- [Architecture Overview](#architecture-overview)
- [Core Components](#core-components)
- [Algorithms](#algorithms)
- [API Reference](#api-reference)
- [Data Structures](#data-structures)
- [Performance Optimization](#performance-optimization)
- [Browser Compatibility](#browser-compatibility)

---

## 🏗️ Architecture Overview

### System Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    User Interface Layer                  │
│  ┌─────────────────┐         ┌────────────────────────┐ │
│  │ Stopwatch Tab   │         │   Video Sync Tab       │ │
│  │ - Canvas Display│         │   - Upload Interface   │ │
│  │ - Controls      │         │   - Processing View    │ │
│  │ - ArUco Markers │         │   - Results Dashboard  │ │
│  └─────────────────┘         └────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────┐
│                  Application Logic Layer                 │
│  ┌──────────────┐  ┌───────────────┐  ┌──────────────┐ │
│  │  Stopwatch   │  │ Video         │  │ Sync         │ │
│  │  Engine      │  │ Processor     │  │ Calculator   │ │
│  └──────────────┘  └───────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────┐
│                  External Libraries Layer                │
│  ┌──────────────┐  ┌───────────────┐  ┌──────────────┐ │
│  │  OpenCV.js   │  │ Tesseract.js  │  │ HTML5 APIs   │ │
│  │  (ArUco)     │  │ (OCR)         │  │ (Video/      │ │
│  │              │  │               │  │  Canvas)     │ │
│  └──────────────┘  └───────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────┘
```

### Data Flow

```
User Action → Event Handler → Processing Function → Update UI
     ↓
File Upload → Video Analysis → Timestamp Extraction → Sync Calculation
     ↓
Display Results → Synchronized Playback
```

---

## 🧩 Core Components

### 1. Stopwatch Module

**File**: `app.js` (lines 1-150)

**Responsibilities**:
- Real-time time tracking
- Canvas-based rendering
- ArUco marker generation
- Control state management

**Key Functions**:
```javascript
initStopwatch()          // Initialize stopwatch system
drawStopwatch()          // Render current time
updateStopwatch()        // Animation loop
generateArUcoMarkers()   // Create marker patterns
drawMarker()             // Render individual marker
```

**State Variables**:
```javascript
stopwatchRunning: boolean    // Running state
stopwatchStartTime: number   // Start timestamp (ms)
stopwatchElapsed: number     // Accumulated time (ms)
```

### 2. Video Processing Module

**File**: `app.js` (lines 151-400)

**Responsibilities**:
- Video file handling
- Frame extraction
- OCR processing
- Timestamp detection

**Key Functions**:
```javascript
processVideo(file, name)           // Main processing pipeline
extractTimestampFromFrame(canvas)  // OCR extraction
parseStopwatchTime(text)          // Parse timestamp string
```

**Processing Pipeline**:
1. Load video file
2. Extract frames at intervals
3. Detect ArUco markers (ROI)
4. Extract timestamp using OCR
5. Store frame-time mappings

### 3. Synchronization Module

**File**: `app.js` (lines 401-550)

**Responsibilities**:
- Timestamp matching
- Offset calculation
- Statistical analysis
- Result generation

**Key Functions**:
```javascript
calculateSyncOffset(dataA, dataB)  // Calculate time offset
displayResults()                   // Show analysis
setupSyncedPlayers()              // Configure playback
```

**Algorithm**:
```javascript
1. For each timestamp in Video A:
   2. Find matching timestamps in Video B (within tolerance)
   3. Calculate offset = videoTime_A - videoTime_B
4. Compute median offset (robust to outliers)
5. Return offset and confidence metrics
```

---

## 🔬 Algorithms

### ArUco Marker Generation

**Purpose**: Create unique visual markers for automated detection

**Algorithm**:
```javascript
function generatePattern(id) {
    // 5x5 binary pattern
    // Border is always 1 (black)
    // Inner 3x3 contains unique ID pattern
    
    const patterns = {
        0: [[1,1,1,1,1],
            [1,0,0,0,1],
            [1,0,1,0,1],
            [1,0,0,0,1],
            [1,1,1,1,1]],
        // ... more patterns
    };
    return patterns[id];
}
```

**Rendering**:
- Each cell is MARKER_SIZE/5 pixels
- Black (1) and white (0) cells
- 2px black border around entire marker

### OCR Timestamp Extraction

**Purpose**: Extract time from stopwatch display in video frames

**Algorithm**:
```javascript
1. Extract ROI (600x200 center region)
2. Convert to grayscale
3. Apply binary threshold (>150 → 255, else 0)
4. Initialize Tesseract worker with digit whitelist
5. Perform OCR recognition
6. Parse result with regex pattern
7. Convert to seconds
```

**Pattern Matching**:
```regex
(\d{2}):(\d{2}):(\d{2})\.(\d{3})
HH:MM:SS.mmm format
```

**Error Correction**:
- O/o → 0 (common OCR mistake)
- l/I → 1 (common OCR mistake)
- S → 5, B → 8 (similarity)

### Synchronization Offset Calculation

**Purpose**: Determine time difference between two video recordings

**Algorithm**:
```javascript
function calculateSyncOffset(dataA, dataB) {
    matches = []
    
    // Find all matching timestamps
    for each timestamp_A in dataA:
        for each timestamp_B in dataB:
            if |stopwatch_time_A - stopwatch_time_B| < TOLERANCE:
                offset = video_time_A - video_time_B
                matches.push(offset)
    
    // Use median for robustness
    matches.sort()
    median_offset = matches[length/2]
    
    return median_offset
}
```

**Tolerance**: 100ms (0.1s) default
- Allows for minor OCR inaccuracies
- Compensates for frame timing variations

**Why Median?**
- Robust to outliers
- Better than mean for noisy data
- Handles OCR errors gracefully

---

## 📚 API Reference

### Global State

```javascript
// Stopwatch state
stopwatchRunning: boolean
stopwatchStartTime: number (ms)
stopwatchElapsed: number (ms)
stopwatchInterval: object

// Video state
videoA: File
videoB: File
videoAData: VideoData
videoBData: VideoData
syncOffset: number (seconds)
```

### Data Types

```typescript
interface VideoData {
    fps: number;
    duration: number;
    timestamps: Timestamp[];
    videoFile: File;
}

interface Timestamp {
    frame: number;
    videoTime: number;     // seconds
    stopwatchTime: number; // seconds
}

interface SyncResult {
    offset: number;        // seconds
    confidence: string;
    matchCount: number;
}
```

### Core Functions

#### Stopwatch Functions

```javascript
initStopwatch()
// Initialize stopwatch system
// Returns: void
// Side effects: Sets up canvas, event listeners

drawStopwatch()
// Render current stopwatch time
// Returns: void
// Side effects: Updates canvas

generateArUcoMarkers()
// Create ArUco marker patterns
// Returns: Array<{id: number, pattern: number[][]}>
```

#### Video Processing Functions

```javascript
async processVideo(videoFile: File, videoName: string)
// Process video and extract timestamps
// Returns: Promise<VideoData>
// Throws: Error if video cannot be loaded

async extractTimestampFromFrame(canvas: HTMLCanvasElement)
// Extract timestamp using OCR
// Returns: Promise<number | null>
// Returns null if timestamp not detected

parseStopwatchTime(text: string)
// Parse timestamp string to seconds
// Returns: number | null
```

#### Synchronization Functions

```javascript
calculateSyncOffset(dataA: VideoData, dataB: VideoData)
// Calculate time offset between videos
// Returns: number (offset in seconds)

displayResults()
// Display synchronization results
// Returns: void
// Side effects: Updates DOM

playSynchronized()
// Start synchronized playback
// Returns: void
// Side effects: Starts both video players
```

---

## ⚡ Performance Optimization

### Current Optimizations

1. **Frame Sampling**
   - Process every 5th frame (configurable)
   - Reduces computation by 80%
   - Minimal impact on accuracy

2. **ROI Extraction**
   - Focus on center 600x200px region
   - Reduces OCR processing area by ~95%
   - Faster, more accurate results

3. **Canvas Caching**
   - Reuse canvas objects
   - Avoid repeated creation/destruction
   - Reduces GC pressure

4. **Progressive Rendering**
   - Update UI during processing
   - Prevents browser freezing
   - Better user experience

### Potential Improvements

1. **Web Workers**
   ```javascript
   // Offload OCR to worker thread
   const worker = new Worker('ocr-worker.js');
   worker.postMessage(frameData);
   ```

2. **GPU Acceleration**
   ```javascript
   // Use WebGL for image processing
   // Can speed up grayscale conversion, thresholding
   ```

3. **Lazy Loading**
   ```javascript
   // Load Tesseract only when needed
   // Reduces initial page load time
   ```

4. **Caching**
   ```javascript
   // Cache processed results
   // Avoid re-processing same videos
   ```

---

## 🌐 Browser Compatibility

### Required APIs

| Feature | Chrome | Firefox | Safari | Edge |
|---------|--------|---------|--------|------|
| Canvas 2D | ✅ 1+ | ✅ 1+ | ✅ 1+ | ✅ 12+ |
| Video API | ✅ 3+ | ✅ 3.5+ | ✅ 3.1+ | ✅ 12+ |
| FileReader | ✅ 6+ | ✅ 3.6+ | ✅ 6+ | ✅ 10+ |
| Promises | ✅ 32+ | ✅ 29+ | ✅ 8+ | ✅ 12+ |
| Async/Await | ✅ 55+ | ✅ 52+ | ✅ 10.1+ | ✅ 15+ |
| ES6 Modules | ✅ 61+ | ✅ 60+ | ✅ 10.1+ | ✅ 16+ |

### Recommended Versions

- **Chrome**: 90+
- **Firefox**: 88+
- **Safari**: 14+
- **Edge**: 90+

### Known Issues

1. **Safari < 14**: Limited video codec support
2. **Firefox**: Slower Canvas rendering
3. **Mobile browsers**: Memory limitations with large videos

### Polyfills

Not required for modern browsers, but can add:
```javascript
// For older browsers
<script src="https://polyfill.io/v3/polyfill.min.js"></script>
```

---

## 🔍 Debugging

### Enable Debug Mode

```javascript
// Add to app.js
const DEBUG = true;

function log(...args) {
    if (DEBUG) console.log(...args);
}

// Use throughout code
log('Processing frame:', frameIndex);
```

### Common Issues

**Issue**: OCR not detecting timestamps
```javascript
// Check:
1. Is stopwatch visible in video?
2. Is lighting good?
3. Check console for Tesseract errors
4. Try increasing SYNC_TOLERANCE
```

**Issue**: Synchronization offset seems wrong
```javascript
// Check:
1. Do videos overlap in time?
2. Are there enough matching timestamps?
3. Review timestamp data section
4. Check for video corruption
```

---

## 📊 Performance Metrics

### Typical Performance

| Metric | Value |
|--------|-------|
| Processing time (60s video) | 30-60 seconds |
| Memory usage | 200-500 MB |
| Timestamp detection rate | 70-90% |
| Sync accuracy | ±0.1 seconds |

### Benchmarking

```javascript
// Add timing code
const start = performance.now();
await processVideo(file);
const end = performance.now();
console.log(`Processing took ${end - start}ms`);
```

---

**For questions or clarifications, open an issue on GitHub!**
