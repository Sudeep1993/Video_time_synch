# 🤝 Contributing to Video Sync App

Thank you for your interest in contributing to the Video Synchronization Tool! This document provides guidelines for contributing to the project.

## 📋 Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [How to Contribute](#how-to-contribute)
- [Development Setup](#development-setup)
- [Coding Standards](#coding-standards)
- [Testing](#testing)
- [Pull Request Process](#pull-request-process)

## 🤗 Code of Conduct

This project adheres to a code of conduct. By participating, you are expected to uphold this code. Please be respectful and constructive in all interactions.

## 🚀 Getting Started

1. **Fork the repository** on GitHub
2. **Clone your fork** locally:
   ```bash
   git clone https://github.com/yourusername/video-sync-app.git
   cd video-sync-app
   ```
3. **Create a branch** for your changes:
   ```bash
   git checkout -b feature/your-feature-name
   ```

## 💡 How to Contribute

### Reporting Bugs

If you find a bug, please create an issue with:
- Clear, descriptive title
- Steps to reproduce the problem
- Expected vs actual behavior
- Screenshots if applicable
- Browser and OS information

### Suggesting Enhancements

Enhancement suggestions are welcome! Please create an issue with:
- Clear description of the feature
- Use cases and benefits
- Possible implementation approach
- Mockups or examples if applicable

### Code Contributions

We welcome code contributions! Areas where you can help:

- **Performance improvements**: Optimize OCR processing, video handling
- **UI/UX enhancements**: Improve design, add animations, better responsiveness
- **Feature additions**: Multi-video sync, export functionality, timeline view
- **Bug fixes**: Fix reported issues
- **Documentation**: Improve guides, add examples, fix typos
- **Testing**: Add unit tests, integration tests

## 🛠️ Development Setup

### Prerequisites

- Modern web browser (Chrome, Firefox, Safari, Edge)
- Text editor or IDE (VS Code recommended)
- Git for version control
- Optional: Node.js for running local server

### Local Development

```bash
# Start local server
python -m http.server 8000
# OR
npx http-server -p 8000

# Open browser
open http://localhost:8000
```

### Project Structure

```
video-sync-app/
├── index.html          # Main HTML file
├── styles.css          # Styling
├── app.js              # Main JavaScript logic
├── README.md           # Project documentation
├── DEPLOYMENT.md       # Deployment guide
├── QUICKSTART.md       # Quick start guide
├── CONTRIBUTING.md     # This file
├── LICENSE             # MIT License
├── package.json        # NPM configuration
└── .gitignore          # Git ignore rules
```

## 📝 Coding Standards

### JavaScript

- Use ES6+ features (arrow functions, const/let, template literals)
- Use meaningful variable and function names
- Add comments for complex logic
- Keep functions small and focused
- Use async/await for asynchronous operations

Example:
```javascript
// Good
async function processVideoFrame(frame, frameIndex) {
    const timestamp = await extractTimestamp(frame);
    return { frameIndex, timestamp };
}

// Avoid
function pf(f, i) {
    // unclear what this does
}
```

### CSS

- Use CSS custom properties for colors and common values
- Mobile-first responsive design
- Use meaningful class names (BEM methodology encouraged)
- Group related properties together

Example:
```css
/* Good */
.video-player {
    width: 100%;
    border-radius: var(--border-radius);
    background-color: var(--bg-color);
}

/* Avoid */
.vp {
    w: 100%;
}
```

### HTML

- Use semantic HTML elements
- Include proper ARIA labels for accessibility
- Keep markup clean and organized
- Add comments for major sections

## 🧪 Testing

Before submitting a pull request:

1. **Manual Testing**:
   - Test on multiple browsers (Chrome, Firefox, Safari)
   - Test on different screen sizes
   - Test with various video formats and sizes
   - Verify all features work as expected

2. **Code Quality**:
   - Run linter (if configured)
   - Check for console errors
   - Verify no broken links or missing resources

3. **Performance**:
   - Test with large video files
   - Check memory usage
   - Verify processing speed is acceptable

## 📤 Pull Request Process

### Before Submitting

1. **Update documentation** if needed
2. **Test thoroughly** on multiple browsers
3. **Follow coding standards**
4. **Update README** if adding features
5. **One feature per PR** (keep changes focused)

### Submitting

1. **Push to your fork**:
   ```bash
   git push origin feature/your-feature-name
   ```

2. **Create Pull Request** on GitHub with:
   - Clear title describing the change
   - Detailed description of what changed and why
   - Screenshots/GIFs for UI changes
   - Link to related issues (if any)

3. **Template**:
   ```markdown
   ## Description
   Brief description of changes
   
   ## Type of Change
   - [ ] Bug fix
   - [ ] New feature
   - [ ] Documentation update
   - [ ] Performance improvement
   
   ## Testing
   - [ ] Tested on Chrome
   - [ ] Tested on Firefox
   - [ ] Tested on Safari
   - [ ] Tested on mobile
   
   ## Screenshots
   (if applicable)
   ```

### Review Process

1. Maintainers will review your PR
2. Address any feedback or requested changes
3. Once approved, your PR will be merged
4. Your contribution will be credited in release notes

## 🎯 Good First Issues

Look for issues labeled `good first issue` or `help wanted` if you're new to the project. These are great starting points!

## 💬 Questions?

- Open an issue for questions
- Check existing issues and documentation first
- Be patient and respectful

## 🏆 Recognition

Contributors will be:
- Listed in release notes
- Credited in README (for significant contributions)
- Added to CONTRIBUTORS.md file

## 📄 License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

**Thank you for contributing! 🎉**
