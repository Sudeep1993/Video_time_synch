# 📸 Screenshots & Demo

## Application Screenshots

### Live Stopwatch Display
The stopwatch with ArUco markers in corners for easy detection during video recording.

*[Screenshot placeholder - Add screenshot of stopwatch display]*

**Features:**
- High-precision timer (milliseconds accuracy)
- Four ArUco markers for automatic detection
- Clean, high-contrast display for OCR
- Start/Pause/Reset controls

---

### Video Upload Interface
Simple drag-and-drop or file selection for both videos.

*[Screenshot placeholder - Add screenshot of upload interface]*

**Features:**
- Support for multiple video formats
- Video preview before processing
- Clear labeling for Video A and Video B
- Visual feedback for uploaded files

---

### Processing Screen
Real-time progress indicator showing the synchronization process.

*[Screenshot placeholder - Add screenshot of processing screen]*

**Features:**
- Progress bar with percentage
- Step-by-step status updates
- Estimated time remaining
- Processing details

---

### Results Dashboard
Comprehensive analysis results with all synchronization data.

*[Screenshot placeholder - Add screenshot of results]*

**Features:**
- Video statistics (FPS, duration, detection rate)
- Calculated time offset
- Confidence metrics
- Number of matched timestamps

---

### Synchronized Playback
Side-by-side video playback with synchronization controls.

*[Screenshot placeholder - Add screenshot of synchronized playback]*

**Features:**
- Dual video players
- Synchronized start/pause/reset
- Real-time timestamp display
- Visual sync offset indicator

---

### Timestamp Analysis
Detailed view of detected timestamps from both videos.

*[Screenshot placeholder - Add screenshot of timestamp data]*

**Features:**
- Frame-by-frame timestamp matching
- Video time vs stopwatch time comparison
- Detection success indicators
- Scrollable timestamp lists

---

## 🎥 Video Demonstration

For a complete walkthrough, check out these demo videos:

1. **Quick Start Tutorial** - 3 minutes
   - Setting up the stopwatch
   - Recording videos
   - Synchronization process

2. **Advanced Features** - 5 minutes
   - Understanding results
   - Troubleshooting tips
   - Best practices

*[Video placeholder - Add links to demo videos]*

---

## 📊 Example Use Cases

### Use Case 1: Multi-Camera Sports Recording
Record the same sports event from different angles and synchronize them perfectly.

### Use Case 2: Interview Recording
Sync camera angles for professional interview videos.

### Use Case 3: Live Performance
Synchronize audience and stage recordings of concerts or performances.

### Use Case 4: Surveillance Analysis
Align multiple security camera feeds for investigation.

---

## 🔗 Live Demo

Try the live application here: **[Live Demo Link]**

---

## 📝 Notes on Screenshots

To add actual screenshots:

1. Take screenshots while running the application
2. Save them in a `screenshots/` folder
3. Update this file with actual image paths:
   ```markdown
   ![Stopwatch Display](screenshots/stopwatch.png)
   ```

Recommended screenshot sizes:
- Desktop views: 1920x1080 or 1280x720
- Mobile views: 375x812 (iPhone) or similar
- Format: PNG for UI, JPG for photos
- Compress images for faster loading

---

**Need help capturing screenshots? Check the CONTRIBUTING.md guide!**
