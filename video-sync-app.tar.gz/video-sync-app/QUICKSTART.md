# 🚀 Quick Start Guide

Get started with the Video Synchronization Tool in 5 minutes!

## 📥 Download or Clone

### Option 1: Download ZIP
1. Click the green "Code" button on GitHub
2. Select "Download ZIP"
3. Extract the files to your computer

### Option 2: Clone with Git
```bash
git clone https://github.com/yourusername/video-sync-app.git
cd video-sync-app
```

## 🌐 Run Locally

### Simple Method (No Installation Required)
Just open `index.html` in your web browser!

> ⚠️ **Note**: Some features require a local server. See methods below.

### With Python (Recommended)
```bash
# Navigate to project folder
cd video-sync-app

# Start server
python -m http.server 8000

# Open browser to:
# http://localhost:8000
```

### With Node.js
```bash
# Install http-server (one-time)
npm install -g http-server

# Start server
http-server -p 8000

# Open browser to:
# http://localhost:8000
```

## 🎥 Usage in 3 Steps

### Step 1: Display Stopwatch
1. Open the application
2. Go to "Live Stopwatch" tab
3. Click "Start"
4. Display this on a screen visible to all cameras

### Step 2: Record Videos
1. Record with multiple cameras
2. Ensure the stopwatch is clearly visible
3. Record for at least 10-15 seconds
4. Stop recording

### Step 3: Synchronize
1. Go to "Video Sync" tab
2. Upload Video A and Video B
3. Click "Process & Synchronize Videos"
4. Wait for processing (30-60 seconds)
5. View synchronized playback!

## 📊 What You'll Get

- **Time offset** between videos (in seconds)
- **Synchronized playback** side-by-side
- **Detection statistics** for both videos
- **Timestamp data** showing matched frames
- **Confidence metrics** for synchronization quality

## 🎯 Tips for Best Results

### Recording Tips
- ✅ Keep stopwatch clearly visible and in focus
- ✅ Ensure good lighting on the stopwatch
- ✅ Record at 30fps or higher
- ✅ Keep camera steady
- ✅ Record at least 10-15 seconds overlap

### Upload Tips
- ✅ Use MP4 or MOV format
- ✅ Keep file size under 500MB for best performance
- ✅ Ensure videos show the same time period
- ✅ Both videos should capture the stopwatch

## ❓ Common Questions

**Q: How long does processing take?**
A: Usually 30-60 seconds depending on video length and your computer speed.

**Q: What video formats are supported?**
A: MP4, MOV, AVI, WebM - most common formats work!

**Q: Can I synchronize more than 2 videos?**
A: Currently supports 2 videos. Multi-video sync is planned for future versions.

**Q: Do my videos need to be uploaded anywhere?**
A: No! Everything processes in your browser. Videos never leave your computer.

**Q: What if synchronization fails?**
A: Check that:
- Stopwatch is clearly visible in both videos
- Videos overlap in time
- Lighting is good
- Try recording again with better visibility

## 🆘 Getting Help

- 📖 Read the full [README.md](README.md)
- 🚀 Check [DEPLOYMENT.md](DEPLOYMENT.md) for hosting
- 🐛 Report issues on GitHub
- 💬 Check browser console for errors

## 🎉 You're Ready!

That's it! You're ready to synchronize your videos.

**Happy Syncing! 🎬**
